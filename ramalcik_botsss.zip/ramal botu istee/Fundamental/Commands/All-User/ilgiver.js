const {
    MessageEmbed,
    MessageButton,
    MessageActionRow
} = require("discord.js");
const Stat = require("../../models/stats");
let limit = new Map();
module.exports.run = async (client, message, args, durum, kanal) => {
    if (!message.guild) return;
		if (limit.get(message.author.id) == "Aktif") return message.reply("20 saniye'de 1 kullanabilirsin asko.");
	limit.set(message.author.id, "Aktif")
	setTimeout(() => {
		limit.delete(message.author.id)
	}, 1000*10)
    if(!message.mentions.members.first()) return message.reply("İlgi vericeğim kişiyi göster bana çabuk!!").then(e => setTimeout(() => e.delete(), 7000))
    let target = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
    
    const oldembed = new MessageEmbed()
.setAuthor(message.author.tag, message.author.avatarURL({ dynamic: true }))
.setColor(client.renk.renksiz)
.setDescription(`${message.mentions.members.first()} Adlı kullanıcıya ilgi vermek için butonları kullan asko`)
if(message.author.id === message.mentions.members.first().id) return message.reply('O kadar yoklukta mısın la kendine ilgi veriyorsun ben veririm dm geçek').then(e => setTimeout(() => e.delete(), 7000))
    const row = new MessageActionRow().addComponents(
        new MessageButton().setCustomId('test').setLabel(`İlgi Ver`).setStyle('SUCCESS'),
        new MessageButton().setCustomId('test2').setLabel(`Yada Verme`).setStyle('DANGER'),) 
        let msg = await message.channel.send({ components: [row], embeds: [oldembed] });
        var filter = (button) => button.user.id === message.author.id;
      const collector = message.channel.createMessageComponentCollector({ filter, time: 30000 })

      collector.on('collect', async (button) => {
        if (button.customId === "test") {       
            const row = new MessageActionRow().addComponents(
                new MessageButton().setCustomId('test3').setLabel(`İlgi Yükleniyor`).setStyle('SUCCESS').setDisabled(true),)
            const oldembed2 = new MessageEmbed()
            .setAuthor(message.author.tag, message.author.avatarURL({ dynamic: true }))
            .setColor(client.renk.renksiz)
            .setDescription(`${message.mentions.members.first()} Adlı kullanıcıya ilgi yükleniyor 😍🥰😛🥺😘❤️‍🔥❤️`)
             msg.edit({embeds: [oldembed2],components: [row]}).then(e => setTimeout(() => e.delete(), 7000))

            
  
  }
          if (button.customId === "test2") {       
            const row = new MessageActionRow().addComponents(
                new MessageButton().setCustomId('test32').setLabel(`Üzgünüm İlgi Yok`).setStyle('DANGER').setDisabled(true),)
                const oldembed22 = new MessageEmbed()
                .setAuthor(message.author.tag, message.author.avatarURL({ dynamic: true }))
                .setColor(client.renk.renksiz)
                .setDescription(`${message.mentions.members.first()} Üzgünüm ilgi veremem o yüzden ağla 😛😘`)
             msg.edit({embeds: [oldembed22],components: [row]}).then(e => setTimeout(() => e.delete(), 7000))
    }
    
    })

      
}
exports.conf = {aliases: ["ilgi"]}
exports.help = {name: 'ilgi'}