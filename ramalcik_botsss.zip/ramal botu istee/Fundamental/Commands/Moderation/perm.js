const {
    MessageEmbed,
    Discord
} = require("discord.js");
const conf = client.ayarlar
let mongoose = require("mongoose");
let sunucuayar = require("../../models/sunucuayar");
const moment = require("moment");
require("moment-duration-format");
const { MessageActionRow, MessageSelectMenu, MessageButton} = require('discord.js');

module.exports.run = async (client, message, args, durum, kanal) => {
    if (!message.guild) return;
    let sunucuData = await sunucuayar.findOne({
        guildID: message.guild.id
    });
    
    let data = await sunucuayar.findOne({})
    if (durum || message.member.roles.cache.get(sunucuData.EnAltYetkiliRol)) {
        let uye = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
        if (!uye) return message.reply({ content:`\`.perm @Kullanıcı/ID\``});
        if(message.author.id === uye.id) return message.reply({content: `\`Kendine Rol Veremezsin dostum!\``, ephemeral: true })
        
        const perm = new MessageActionRow()
        .addComponents(
            new MessageSelectMenu()
                .setCustomId('perm')
                .setPlaceholder('Eklemek istediğiniz perm için tıklayınız')
                .addOptions([
                    {
                        label: 'Vip',
                        value: 'vip',
                    
                    },
                    {
                        label: 'Müzisyen',
                        value: 'müzisyen',
                   
                    },						
                    {
                        label: 'Designer',
                        value: 'tasarımcı',
                   
                    },
                    {
                      label: 'Castle Sponsor',
                      value: 'sorun',
                 
                  },
                    
                ]),
        );
        
        const msg = await message.reply({ content : `${uye} kullanıcısına perm eklemek için aşağıdaki menüyü kullanınız`, components: [perm] });
        
        const filter = i => i.user.id == message.author.id 
        const collector = msg.createMessageComponentCollector({ filter, componentType: 'SELECT_MENU', max: 1, time: 20000 });
        collector.on("collect", async (interaction) => {
        
let ayar = {
    "vipRole": "1037078064917663805",
    "müzisyenRole": "1038948957436530698",
    "tasarımcıRole": "1037078066704416818",
    "sorunçözücüRole":"1037078066419220602"
  
  
  }
             if (interaction.values[0] === "vip") {
                uye.roles.cache.has(ayar.vipRole) ? uye.roles.remove(ayar.vipRole) : uye.roles.add(ayar.vipRole);
                if(!uye.roles.cache.has(ayar.vipRole)) {
                  let embed = new MessageEmbed()
                  client.channels.cache.find(x => x.name == "perm-log").send({ embeds: [embed.setDescription(`${uye} isimli kişiye **${moment(Date.now()).format("LLL")}** tarihinde ${message.author} tarafından **Vip** adlı rol verildi.`)]})
                  msg.edit({ content:`Başarıyla ${uye}, isimli kişiye **Vip** rolü verildi.`, components: [] });
                } else {
                  client.channels.cache.find(x => x.name == "perm-log").send({ embeds: [embed.setDescription(`${uye} isimli kişiye **${moment(Date.now()).format("LLL")}** tarihinde ${message.author} tarafından **Vip** adlı rol geri alındı.`)]})
                  msg.edit({ content:`Başarıyla ${uye}, isimli kişinin **Vip** rolü geri alındı.`, components: [] });
                };
             }
        
             if (interaction.values[0] === "müzisyen") {
                uye.roles.cache.has(ayar.müzisyenRole) ? uye.roles.remove(ayar.müzisyenRole) : uye.roles.add(ayar.müzisyenRole);
                if(!uye.roles.cache.has(ayar.müzisyenRole)) {
                  let embed = new MessageEmbed()
                  client.channels.cache.find(x => x.name == "perm-log").send({ embeds: [embed.setDescription(`${uye} isimli kişiye **${moment(Date.now()).format("LLL")}** tarihinde ${message.author} tarafından **Müzisyen** adlı rol verildi.`)]})
                  msg.edit({ content:`Başarıyla ${uye}, isimli kişiye **Müzisyen** rolü verildi.`, components: [] });
                } else {
                  client.channels.cache.find(x => x.name == "perm-log").send({ embeds: [embed.setDescription(`${uye} isimli kişiye **${moment(Date.now()).format("LLL")}** tarihinde ${message.author} tarafından **Müzisyen** adlı rol geri alındı.`)]})
                  msg.edit({ content:`Başarıyla ${uye}, isimli kişinin **Müzisyen** rolü geri alındı.`, components: [] });
                };
             }
        
            if (interaction.values[0] === "tasarımcı") {
                uye.roles.cache.has(ayar.tasarımcıRole) ? uye.roles.remove(ayar.tasarımcıRole) : uye.roles.add(ayar.tasarımcıRole);
                if(!uye.roles.cache.has(ayar.tasarımcıRole)) {
                  let embed = new MessageEmbed()
                  client.channels.cache.find(x => x.name == "perm-log").send({ embeds: [embed.setDescription(`${uye} isimli kişiye **${moment(Date.now()).format("LLL")}** tarihinde ${message.author} tarafından **Designer** adlı rol verildi.`)]})
                  msg.edit({ content:`Başarıyla ${uye}, isimli kişiye **Designer** rolü verildi.`, components: [] });
                } else {
                  client.channels.cache.find(x => x.name == "perm-log").send({ embeds: [embed.setDescription(`${uye} isimli kişiye **${moment(Date.now()).format("LLL")}** tarihinde ${message.author} tarafından **Designer** adlı rol geri alındı.`)]})
                  msg.edit({ content:`Başarıyla ${uye}, isimli kişinin **Designer** rolü geri alındı.`, components: [] });
                };
             }
        
            if (interaction.values[0] === "sorun") {
                uye.roles.cache.has(ayar.sorunçözücüRole) ? uye.roles.remove(ayar.sorunçözücüRole) : uye.roles.add(ayar.sorunçözücüRole);
                if(!uye.roles.cache.has(ayar.sorunçözücüRole)) {
                  let embed = new MessageEmbed()
                  client.channels.cache.find(x => x.name == "perm-log").send({ embeds: [embed.setDescription(`${uye} isimli kişiye **${moment(Date.now()).format("LLL")}** tarihinde ${message.author} tarafından **Castle Sponsor** adlı rol verildi.`)]})
                  msg.edit({ content:`Başarıyla ${uye}, isimli kişiye **Castle Sponsor** rolü verildi.`, components: [] });
                } else {
                  client.channels.cache.find(x => x.name == "perm-log").send({ embeds: [embed.setDescription(`${uye} isimli kişiye **${moment(Date.now()).format("LLL")}** tarihinde ${message.author} tarafından **Castle Sponsor** adlı rol geri alındı.`)]})
                  msg.edit({ content:`Başarıyla ${uye}, isimli kişinin **Castle Sponsor** rolü geri alındı.`, components: [] });
                };
             }
            })
        
        }
        }
            
exports.conf = {
    aliases: ["perm","vip"]
}
exports.help = {
    name: 'vip'
}
