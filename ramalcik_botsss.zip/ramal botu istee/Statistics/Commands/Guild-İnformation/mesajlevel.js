const { Client, MessageEmbed, MessageAttachment, MessageActionRow, MessageSelectMenu, MessageButton, } = require('discord.js');
const Canvas = require('canvas')
require("moment-timezone")
const ayarlar = require("../../../settings")
let Stat = require("../../models/stats");
module.exports.run = async (client, message, args, durum, kanal) => {
    if (!message.guild) return;
        
        let target = message.mentions.members.first() || message.guild.members.cache.get(args[0]) || message.member;
        let data = await Stat.findOne({userID: target.id, guildID: message.guild.id});
        let member = await message.guild.members.fetch(target.id)
        const canvacord = require("canvacord");
        const background = "https://media.discordapp.net/attachments/1057308367065993297/1080161523151945758/1111111.png"
        const rank = new canvacord.Rank()
            .setAvatar(target.displayAvatarURL())
            .setCurrentXP(typeof data?.messageXP === "object" ? 0 : data?.messageXP)
            .setRequiredXP(data.messageLevel * 643)
            .setStatus(member.presence?.status || "offline")
            .setProgressBar("#FFFFFF", "COLOR")
            .setLevel(typeof data?.messageLevel === "object" ? 0 : data?.messageLevel)
            .setUsername(target.user.username)
            .setDiscriminator(target.user.discriminator)
            .setBackground("IMAGE", background);

        rank.build()
            .then(async data => {
                const attachment = new MessageAttachment(data, "RankCard.png");
                let msg = await message.reply({ content:`> ${target} **Kullanıcısının Mesaj Level Göstergesi**`, files: [attachment] , components: [] })
           
    
            var filter = (button) => button.user.id === message.author.id;
            const collector = msg.createMessageComponentCollector({ filter, time: 90000 })
    
            collector.on('collect', async (button) => {
                if (button.customId === "toplevel") {
                row.components[0].setDisabled(true) 
                msg.edit({ components: [row] }); 
                let data = await Stat.find({}, {messageXP: 0, _id: 0, __v: 0,ondort: 0,total: 0, yirmibir: 0, yirmisekiz: 0, otuzbes: 0, messageCategory: 0, voiceChannel: 0, voiceCategory: 0, messageChannel: 0});
        let statemoji = client.emojis.cache.find(x => x.name === "stat");
    
        let göster = data.map(x => {
            return {
                Id: x.userID,
                mLevel: x.messageLevel,
                sLevel: x.voiceLevel,
                total: x.messageLevel+x.voiceLevel
            }
        }).sort((a, b) => b.total - a.total).map((user, index) => `${statemoji} <@${user.Id}> (\`Mesaj: ${user.mLevel} - Ses: ${user.sLevel}\`)`).splice(0,10)
        let embed = new MessageEmbed().setColor(client.renk.renksiz).setFooter(`${message.guild.name} Sunucusuna ait level sıralaması yukarıda belirtildiği gibidir.`).setTitle("Top 10 Ses / Mesaj Level Sıralaması")          .setAuthor(message.guild.name, message.guild.iconURL({dynamic: true})).setDescription(`${göster.join("\n")}`)
                button.reply({embeds: [embed],ephemeral: true})
               
            }
            })  
            collector.on('end', async (button, reason) => {
                row.components[0].setDisabled(true) 
                msg.edit({ components: [row] }); 
                
            }) })

        
function progressBar(maxWidth, requiredXP, currentXP) {
    const percentage = currentXP < 0 ? 0 : currentXP >= requiredXP ? 0.1 / 0.1  : currentXP / requiredXP;
    const progress = Math.round((currentXP * percentage));
    const emptyProgress = currentXP - progress;
    const progressText = `${client.emojis.cache.find(x => x.name == "ortabar")}`.repeat(progress);
    const emptyProgressText = `${client.emojis.cache.find(x => x.name == "griortabar")}`.repeat(emptyProgress);
    const bar = `${maxWidth ? client.emojis.cache.find(x => x.name == "solbar") : client.emojis.cache.find(x => x.name == "baslangicbar")}` + progressText + emptyProgressText + `${emptyProgress == 0 ? `${client.emojis.cache.find(x => x.name === "bitisbar")}` : `${client.emojis.cache.find(x => x.name === "gribitisbar")}`}`;
    return bar;
};

}
exports.conf = {
    aliases: ["mlevel","mlvl","mesaj-level","chatmesaj","lvl","messajlevel"]
}
exports.help = {
    name: 'mesajlevel'
}


function yuzdelik(currentXP, requiredXP, maxWidth) {
    let miktar = currentXP;
    let istenen = requiredXP;
    return parseInt((miktar / istenen) * 100);
}
function getProgressBarWidth(currentXP, requiredXP, maxWidth) {
    if ((currentXP+0.1) > requiredXP) return maxWidth;

    let width = currentXP <= 0 ? 0 : ((currentXP+0.1) * maxWidth) / requiredXP;
    if (width > maxWidth) width = maxWidth;
    return width;
}
function progressBare(currentXP, maxWidth, requiredXP) {
    const percentage = currentXP < 0 ? 0 : currentXP >= maxWidth ? 20 / 20 : currentXP / maxWidth;
    const progress = Math.round((requiredXP * percentage));
    const emptyProgress = requiredXP - progress;
    const progressText = `${client.emojis.cache.find(x => x.name == "ortabar")}`.repeat(progress);
    const emptyProgressText = `${client.emojis.cache.find(x => x.name == "griortabar")}`.repeat(emptyProgress);
    const bar = `${currentXP ? client.emojis.cache.find(x => x.name == "solbar") : client.emojis.cache.find(x => x.name == "baslangicbar")}` + progressText + emptyProgressText + `${emptyProgress == 0 ? `${client.emojis.cache.find(x => x.name === "bitisbar")}` : `${client.emojis.cache.find(x => x.name === "gribitisbar")}`}`;
    return bar;
};
