
const {
    MessageEmbed,
    MessageActionRow,
    MessageSelectMenu,
    MessageButton,
    MessageAttachment

} = require('discord.js');
const yetkiliDB = require("../../models/yetkili");
const Stat = require("../../models/stats");
let profil = require("../../models/profil");
let xpData = require("../../models/stafxp");
let puansystem = require("../../models/puansystem");
let Database = require("../../models/invite");
let moment = require("moment");
let missionSystem = require("../../models/randomMission");
let taglıData = require("../../models/taglıUye");
require("moment-duration-format")
const Canvas = require("canvas");
const canvacord = require("canvacord");
moment.locale("tr")

module.exports.run = async (client, message, args, durum, kanal) => {
    if (!message.guild) return;
    if (kanal) return;
   
    
    let target = message.mentions.members.first() || message.guild.members.cache.get(args[0]) || message.member;
    let profilData = await profil.findOne({
        userID: target.id,
        guildID: message.guild.id
    }) || {
        userID: target.id,
        guildID: message.guild.id,
        BanAmount: 0,
        JailAmount: 0,
        MuteAmount: 0,
        VoiceMuteAmount: 0
    };
    let data = await Stat.findOne({
        userID: target.id,
        guildID: message.guild.id
    }) || {
        yedi: {
            Chat: {},
            Voice: {},
            TagMember: 0,
            Invite: 0,
            Register: 0,
            Yetkili: 0
        },
        messageChannel: {}
    };
    let invite = data.yedi.Invite;
    let data2 = await taglıData.find({
        authorID: target.id,
        Durum: "puan"
    }) || [];
    let yetkiliData = await yetkiliDB.find({
        authorID: target.id,
        Durum: "puan"
    }) || [];
    let kanallar = await puansystem.findOne({
        guildID: message.guild.id
    });
    let puan = await xpData.findOne({
        userID: target.id
    }) || {
        currentXP: 0
    };

    let yetkiler = kanallar.PuanRolSystem;
    let ekPuan = puan.currentXP;

    let pubPuan = target.roles.cache.some(rol => [].includes(rol.id)) ? kanallar.PublicKanallar.Puan * 1.2 : kanallar.PublicKanallar.Puan;
    let oyunPuan = target.roles.cache.some(rol => kanallar.GameKanallar.Rol.includes(rol.id)) ? 8 : kanallar.GameKanallar.Puan;
    let kayitPuan = target.roles.cache.some(rol => kanallar.KayitKanallar.Rol.includes(rol.id)) ? 12 : kanallar.KayitKanallar.Puan;
    let streamPuan = target.roles.cache.some(rol => [].includes(rol.id)) ? kanallar.StreamKanallar.Puan * 1.2 : kanallar.StreamKanallar.Puan;
    let secretPuan = target.roles.cache.some(rol => kanallar.SecretKanallar.Rol.includes(rol.id)) ? 2 : kanallar.SecretKanallar.Puan;
    let mesajPuan = target.roles.cache.some(rol => [].includes(rol.id)) ? kanallar.MesajKanallar.Puan * 1.2 : kanallar.MesajKanallar.Puan;
    let sleepPuan = target.roles.cache.some(rol => kanallar.SleepingKanal.Rol.includes(rol.id)) ? 3 : kanallar.SleepingKanal.Puan;
    let alonePuan = target.roles.cache.some(rol => kanallar.AloneKanallar.Rol.includes(rol.id)) ? 2 : kanallar.AloneKanallar.Puan;
    let musicPuan = target.roles.cache.some(rol => kanallar.Müzik.Rol.includes(rol.id)) ? 2 : kanallar.Müzik.Puan;
    let taglıPuan = target.roles.cache.some(rol => kanallar.TagMember.Rol.includes(rol.id)) ? 30 : kanallar.TagMember.Puan;
    let invitePuan = target.roles.cache.some(rol => kanallar.Invite.Rol.includes(rol.id)) ? 12 : kanallar.Invite.Puan;
    let teyitPuan = target.roles.cache.some(rol => kanallar.Register.Rol.includes(rol.id)) ? 5 : kanallar.Register.Puan;
    let terapipuan = target.roles.cache.some(rol => kanallar.TerapiKanallar.Rol.includes(rol.id)) ? 10 : kanallar.TerapiKanallar.Puan;
    let sorunçözmepuan = target.roles.cache.some(rol => kanallar.SorunCozmeKanallar.Rol.includes(rol.id)) ? 10 : kanallar.SorunCozmeKanallar.Puan;
    let meetingPuan = target.roles.cache.some(rol => kanallar.Toplantı.Rol.includes(rol.id)) ? 10 : kanallar.Toplantı.Puan;
    let yetkiliPuan = target.roles.cache.some(rol => kanallar.Yetkili.Rol.includes(rol.id)) ? 25 : kanallar.Yetkili.Puan;


    let pubOda = yetkiliStat(data.yedi.Voice, kanallar.PublicKanallar.Id, kanallar.SleepingKanal.Id);
    let oyunodalar = yetkiliStat(data.yedi.Voice, kanallar.GameKanallar.Id, []);
    let kayıt = yetkiliStat(data.yedi.Voice, kanallar.KayitKanallar.Id, []);
    let stream = yetkiliStat(data.yedi.Voice, kanallar.StreamKanallar.Id, []);
    let secret = yetkiliStat(data.yedi.Voice, kanallar.SecretKanallar.Id, []);
    let mesaj = data.yedi.Chat ? yetkiliStat(data.yedi.Chat, kanallar.MesajKanallar.Id, []) : 0;
    let sleeping;
    if (!data.yedi.Voice) sleeping = 0;
    else sleeping = data.yedi.Voice[kanallar.SleepingKanal.Id] || 0;
    let alone = yetkiliStat(data.yedi.Voice, kanallar.AloneKanallar.Id, []);
    let music = yetkiliStat(data.yedi.Voice, kanallar.Müzik.Id, []);
    let terapi = yetkiliStat(data.yedi.Voice, kanallar.TerapiKanallar.Id, []);
    let sçözme = yetkiliStat(data.yedi.Voice, kanallar.SorunCozmeKanallar.Id, []);
    let meeting = yetkiliStat(data.yedi.Voice, kanallar.Toplantı.Id, []);
    let yetkili = yetkiliData.length;
    let taglı = data2.length;
    let invite2 = data.yedi.Invite;
    let teyit = data.yedi.Register;

    let totalpoints = parseInt((pubOda / (1000 * 60 * 60 * 1) * pubPuan)) +
        parseInt((oyunodalar / (1000 * 60 * 60 * 1) * oyunPuan)) +
        parseInt((kayıt / (1000 * 60 * 60 * 1) * kayitPuan)) +
        parseInt((stream / (1000 * 60 * 60 * 1) * streamPuan)) +
        parseInt((secret / (1000 * 60 * 60 * 1) * secretPuan)) +
        parseInt((mesaj * mesajPuan)) +
        parseInt((sleeping / (1000 * 60 * 60 * 1) * sleepPuan)) +
        parseInt((alone / (1000 * 60 * 60 * 1) * alonePuan)) +
        parseInt((music / (1000 * 60 * 60 * 1) * musicPuan)) +
        parseInt((terapi / (1000 * 60 * 60 * 1) * terapipuan)) +
        parseInt((sçözme / (1000 * 60 * 60 * 1) * sorunçözmepuan)) +
        parseInt((meeting / (1000 * 60 * 60 * 1) * meetingPuan)) +
        parseInt((yetkili * yetkiliPuan)) +
        parseInt((teyit * teyitPuan)) +
        parseInt((taglı * taglıPuan)) +
        parseInt((invite2 * invitePuan)) + Number(data.EtkinlikPuan)

    let mission = await missionSystem.findOne({
        userID: target.id
    })
    let eglencepuan = parseInt((stream / (1000 * 60 * 60 * 1) * streamPuan)) + parseInt((oyunodalar / (1000 * 60 * 60 * 1) * oyunPuan)) + parseInt((music / (1000 * 60 * 60 * 1) * musicPuan));
    let ses = client.convertDuration(data.totalVoice);

    
    const row2 = new MessageActionRow()
    .addComponents(
      new MessageButton()
        .setCustomId('günlük')
        .setLabel("Günlük")
        .setStyle('SUCCESS'),
        new MessageButton()
        .setCustomId('haftalık')
        .setLabel("Haftalık")
        .setStyle('SUCCESS'),
        new MessageButton()
        .setCustomId('aylık')
        .setLabel("Aylık")
        .setStyle('SUCCESS'),
    );


    const row = new MessageActionRow().addComponents(
        new MessageSelectMenu()
          .setPlaceholder('İstatistiklerini Detaylı Görüntüle!')
          .setCustomId('kurulumselect')
          .addOptions([
            {
                label: "İstatistik Bilgi",
                description: "Level İstatistiklerini Görüntüle!",
                value: "menü",
          },
          { 
              label: "Ceza Kullanım",
              value: "ceza",
              description: "Ceza İstatistiklerini Görüntüle!",

          },
          { 
            label: "Coin Durumu",
            value: "coin",
            description: "Coin Durumunu Görüntüle!",

          },
          { 
            label: "Yetki Atlama Durumu",
            value: "statsex",
            description: "Yetki Puan Durumunu Görüntüle!",

          },

        ])
        );
    

    let statemoji = client.emojis.cache.find(x => x.name === "mav2");
    let BanMiktar = profilData.BanAmount
    let JailMiktar = profilData.JailAmount
    let MuteMiktar = profilData.MuteAmount;
    let SesMuteMiktar = profilData.VoiceMuteAmount
    Stat.findOne({
        userID: target.id,
        guildID: message.guild.id
    }, (err, data) => {
        if (!data) data = {
            yedi: {
                Voice: {},
                Chat: {}
            },
            voiceCategory: {},
            voiceChannel: {},
            messageChannel: {},
            voiceLevel: 1,
            messageLevel: 1,
            voiceXP: 0,
            messageXP: 0,
            coin: 0.0
        }
        let voiceCategory = Object.keys(data.voiceCategory).splice(0, 10).sort(function (a, b) {
            return data.voiceCategory[b] - data.voiceCategory[a]
        }).map((x, index) => `${statemoji} ${message.guild.channels.cache.get(x) ? message.guild.channels.cache.get(x).name : "#kanal-silindi"} \`${client.convertDuration(data.voiceCategory[x])}\``).join("\n");
        
        let voiceChannel = Object.keys(data.voiceChannel).splice(0, 10).sort(function (a, b) {
            return data.voiceChannel[b] - data.voiceChannel[a]
        }).map((x, index) => `${statemoji} ${message.guild.channels.cache.get(x) ? message.guild.channels.cache.get(x).name : "#kanal-silindi"} \`${client.convertDuration(data.voiceChannel[x])}\``).join("\n");
        let messageChannel = Object.keys(data.messageChannel).splice(0, 5).sort(function (a, b) {
            return data.messageChannel[b] - data.messageChannel[a]
        }).map((x, index) => `${statemoji} ${message.guild.channels.cache.get(x) ? message.guild.channels.cache.get(x).name : "#kanal-silindi"} \`${data.messageChannel[x]} mesaj\``).join("\n");

        let embed = new MessageEmbed()
            .setColor(client.renk.renksiz)
            .setFooter(client.ayarlar.footer)
            .setAuthor({ name: message.author.tag, iconURL: message.author.avatarURL({dynamic: true})})
           
            .setDescription(`${target} (<@&${target.roles.highest.id}>) üyesinin <t:${Math.floor(Math.floor(Date.now()) / 1000)}:R> tarihinden  itibaren \`${message.guild.name}\` sunucusunda toplam ses ve mesaj bilgileri aşağıda belirtilmiştir.\n`)
        embed.addField("__**Toplam Ses**__", `\`\`\`js\n${client.convertDuration(data.totalVoice)}\`\`\``, true)
        embed.addField("__**Toplam Mesaj**__", `\`\`\`js\n${data.totalMessage} mesaj\`\`\``, true)
        embed.addField("__**Toplam Davet**__", `\`\`\`js\n${invite ? invite + " Davet" : "Veri Bulunamadı"}\`\`\``, true)
        embed.addField(`**__Kategori Bilgileri__**`, `${voiceCategory ? voiceCategory : "Veriler henüz yüklenmedi"}`)
        embed.addField(`**__Kanal Sıralaması__**`, `${voiceChannel ? voiceChannel : "Veriler henüz yüklenmedi"}`)
        embed.addField(`**__Mesaj Kanal Sıralaması__**`, `${messageChannel ? messageChannel : "Veriler henüz yüklenmedi"}`)


      let msg =  message.reply({ components: [row,row2], embeds: [embed] }).then(async m => {
        let collector = m.createMessageComponentCollector({ filter: row => row.member.user.id === message.author.id, max: 5, time: 30000, errors: ['time'] })
        collector.on('collect', async (interaction) => {
            
            if(interaction.values == "menü") {
                let embed = new MessageEmbed()
            .setColor(client.renk.renksiz)
            .setFooter(client.ayarlar.footer)
            .setAuthor({ name: message.author.tag, iconURL: message.author.avatarURL({dynamic: true})})
           
            .setDescription(`${target} (<@&${target.roles.highest.id}>) üyesinin <t:${Math.floor(Math.floor(Date.now()) / 1000)}:R> tarihinden  itibaren \`${message.guild.name}\` sunucusunda toplam ses ve mesaj bilgileri aşağıda belirtilmiştir.\n`)
        embed.addField("__**Toplam Ses**__", `\`\`\`js\n${client.convertDuration(data.totalVoice)}\`\`\``, true)
        embed.addField("__**Toplam Mesaj**__", `\`\`\`js\n${data.totalMessage} mesaj\`\`\``, true)
        embed.addField("__**Toplam Davet**__", `\`\`\`js\n${invite ? invite + " Davet" : "Veri Bulunamadı"}\`\`\``, true)
        embed.addField(`**__Kategori Bilgileri__**`, `${voiceCategory ? voiceCategory : "Veriler henüz yüklenmedi"}`)
        embed.addField(`**__Kanal Sıralaması__**`, `${voiceChannel ? voiceChannel : "Veriler henüz yüklenmedi"}`)
        embed.addField(`**__Mesaj Kanal Sıralaması__**`, `${messageChannel ? messageChannel : "Veriler henüz yüklenmedi"}`)
            interaction.update({ components: [row,row2], embeds: [embed]})}	

    if(interaction.values == "level") {
        let embed = new MessageEmbed().setColor(client.renk.renksiz)
                .setAuthor({ name: message.author.tag, iconURL: message.author.avatarURL({dynamic: true})})
                .setFooter(ayarlar.footer)
                .setDescription(`\`${message.guild.name}\` Sunucusundaki mesaj ve ses level bilgilerin aşağıda belirtilmiştir.
                \`\`\`js\nMesaj Level Bilgileri: ${data.messageLevel} Levelsin! (${data.messageXP.toFixed(0)}/${data.messageLevel*643})\n\nMesaj Levelinin %${yuzdelik(data.messageXP, data.messageLevel*643, 232)} bölümünü tamamlamışsın!\`\`\`
                \`\`\`js\nSes Level Bilgileri: ${data.voiceLevel} Levelsin! (${data.voiceLevel.toFixed(0)}/${data.messageLevel*643})\n\nSes Levelinin %${yuzdelik(data.voiceXP, data.voiceLevel*643, 232)} tamamlamışsın\`\`\`
                `)
        
    interaction.update({ components: [row,row2], embeds: [embed]})}	

    
    if(interaction.values == "ceza") {
        let embed = new MessageEmbed().setColor(client.renk.renksiz)
                .setAuthor({ name: message.author.tag, iconURL: message.author.avatarURL({dynamic: true})})
                .setFooter(ayarlar.footer)
                .setDescription(`\`${message.guild.name}\` Sunucusundaki **__Cezalandırma Durumu__** aşağıda belirtilmiştir.
                \`\`\`js\nBan komutu kullanım sayısı: ${BanMiktar?BanMiktar: "Veri Bulunamadı"}\`\`\`
                \`\`\`js\nMute komutu kullanım sayısı: ${MuteMiktar?MuteMiktar: "Veri Bulunamadı"}\`\`\`
                \`\`\`js\nSes Mute komutu kullanım sayısı: ${SesMuteMiktar?SesMuteMiktar: "Veri Bulunamadı"}\`\`\`
                \`\`\`js\nJail komutu kullanım sayısı: ${JailMiktar?JailMiktar: "Veri Bulunamadı"}\`\`\`
                `)
               
                
    interaction.update({ components: [row,row2], embeds: [embed]})}		 
    if(interaction.values == "coin") {
        let embed = new MessageEmbed().setColor(client.renk.renksiz)
                .setAuthor({ name: message.author.tag, iconURL: message.author.avatarURL({dynamic: true})})
                .setFooter(ayarlar.footer)
                .setDescription(`\`${message.guild.name}\` Sunucusundaki **__Coin/Para__** Durumu aşağıda belirtilmiştir.
                \`\`\`js\nCoin: ${data.coin.toFixed(1)}\`\`\`
                \`\`\`js\nPara: ${data.para.toFixed(1)}\`\`\``)
    
               
                
    interaction.update({ components: [row,row2], embeds: [embed]})}		
    if(interaction.values == "statsex") {
        let embed5 = new MessageEmbed().setAuthor({ name: target.user.tag, iconURL: target.user.avatarURL({ dynamic: true })}).setColor("2F3136").setFooter(client.ayarlar.footer)
    embed5.setDescription(
        `${target},(${target.roles.highest}) Kullanıcısının <t:${Math.floor(Date.now() / 1000)}:R> tarihinden itibaren \`${message.guild.name}\` verileri. Aşağıdaki Menüden İstediğiniz Verinin İstatistiğine Bakabilirsiniz\n`)
    .addField(`\`➜\` Yetki Durumu`, `${yetkiler.filter(user => target.roles.cache.get(user.ROLE_1)).length > 0 ? yetkiler.filter(user => target.roles.cache.get(user.ROLE_1)).map(y => `\`➜\` Yetki atlama durumunuz \`${totalpoints+parseInt(ekPuan) >= y.PUAN ? "Atlamaya uygun" : totalpoints+parseInt(ekPuan) >=( y.PUAN /2) ? "Atlamaya yakın": "Atlamaya uygun değil."}\`\n
    \`➜\` **Puan Durumu**
    Puanınız: \`${totalpoints+parseInt(ekPuan)}\` Gereken Puan: \`${y.PUAN}\`
    ${progressBar(totalpoints+parseInt(ekPuan), y.PUAN, 6)}  \`${totalpoints+parseInt(ekPuan)} / ${y.PUAN}\`
    ${totalpoints+parseInt(ekPuan) >= y.PUAN ? `
    \`➜\`**Yetki Atlayabilirsin!**
    Gerekli \`Puan\`'a ulaşarak <@&${y.ROLE_2}> yetkisine atlama hakkı kazandın!` : target.roles.cache.get(y.ROLE_1) ? `
    \`➜\` **Yetki Durumu**
    Şuan <@&${y.ROLE_1}> rolündesiniz. <@&${y.ROLE_2}> rolüne ulaşmak için **${Number(y.PUAN-(totalpoints+parseInt(ekPuan)).toFixed(0))}** \`Puan\` kazanmanız gerekiyor\n` : ""}`) : "**Üzerinde bir rol olmadığı için yükselme tablosunu gösteremiyorum.**"}`)
    
    interaction.update({ components: [row,row2], embeds: [embed5] })} 


    if (interaction.customId === "günlük") {
        let canvas = Canvas.createCanvas(1080, 400),
        
        ctx = canvas.getContext("2d");
        let background = await Canvas.loadImage("https://media.discordapp.net/attachments/1080865598327750806/1080865646994280568/sexxxxx.png");
        ctx.drawImage(background, 0, 0, 1080, 400);
        ctx.textAlign = 'center';
        ctx.font = '35px Sans';
        ctx.fillStyle = '#FFFFFF';
        ctx.fillText(`${client.convertDuration(data.dailyVoice)}`, canvas.width / 1.12, 230);
        ctx.font = '35px Sans';
        ctx.fillStyle = '#FFFFFF';
        ctx.fillText(`${client.convertDuration(data.weeklyVoice)}`, canvas.width / 1.12, 290);
        ctx.font = '35px Sans';
        ctx.fillStyle = '#FFFFFF';
        ctx.fillText(`${client.convertDuration(data.monthlyVoice)}`, canvas.width / 1.12, 350);

        ctx.textAlign = 'center';
        ctx.font = '35px Sans';
        ctx.fillStyle = '#FFFFFF';
        ctx.fillText(`${data.dailyMessage} msj`, canvas.width / 1.75, 230);
        ctx.font = '35px Sans';
        ctx.fillStyle = '#FFFFFF';
        ctx.fillText(`${data.weeklyMessage} msj`, canvas.width / 1.75, 290);
        ctx.font = '35px Sans';
        ctx.fillStyle = '#FFFFFF';
        ctx.fillText(`${data.monthlyMessage} msj`, canvas.width / 1.75, 350);

        ctx.font = '35px Sans';
        ctx.fillStyle = '#FFFFFF';
        ctx.fillText(`${client.convertDuration(data.totalVoice)}`, canvas.width / 4.07, 290);
        ctx.font = '35px Sans';
        ctx.fillStyle = '#FFFFFF';
        ctx.fillText(`${data.totalMessage} msj`, canvas.width / 4.07, 230);
        ctx.font = '35px Sans';
        ctx.fillStyle = '#FFFFFF';
        ctx.fillText(`sg yok bişi`, canvas.width / 4.07, 350);
        ctx.font = '50px Sans';
        let member = message.guild.members.cache.get(target.id);
        let nickname = member.displayName == target.username ? "" + target.username + " [Yok] " : member.displayName
        ctx.fillText(`${nickname}`, canvas.width / 4.80, 95);

        ctx.font = '28px Sans';
        ctx.fillStyle = '#FFFFFF';
        ctx.fillText(`${moment(target.user.createdAt).format("L")}`, canvas.width / 1.45, 95);

        ctx.font = '28px Sans';
        ctx.fillStyle = '#FFFFFF';
        ctx.fillText(`${moment(target.joinedAt).format("L")}`, canvas.width / 1.12, 95);
    
            const img = new MessageAttachment(canvas.toBuffer(), 'oy.png');
        Database.find({
            guildID: message.guild.id,
            inviterID: target.id
        }).sort().exec((err, inviterMembers) => {
            let dailyInvites = 0;
            if (inviterMembers.length) {
                dailyInvites = inviterMembers.filter(x => message.guild.members.cache.has(x.userID) && (Date.now() - message.guild.members.cache.get(x.userID).joinedTimestamp) < 1000 * 60 * 60 * 24 * 7).length;
            };
            let aylıkinvite = 0;
            if (inviterMembers.length) {
                aylıkinvite = inviterMembers.filter(x => message.guild.members.cache.has(x.userID) && (Date.now() - message.guild.members.cache.get(x.userID).joinedTimestamp) < 1000 * 60 * 60 * 24 * 30).length;
            }

           
          
            
            
            let embed = new MessageEmbed()
            .setColor(client.renk.renksiz)
            .setFooter(client.ayarlar.footer)
            .setAuthor({ name: message.author.tag, iconURL: message.author.avatarURL({dynamic: true})})
            .setImage('attachment://oy.png')
            .setDescription(`${target} (<@&${target.roles.highest.id}>) üyesinin \` 1 GÜNLÜK \` \`${message.guild.name}\` sunucusunda ki toplam ses ve mesaj bilgileri aşağıda belirtilmiştir.\n`)
        embed.addField("__**Günlük Ses**__", `\`\`\`js\n${client.convertDuration(data.dailyVoice)}\`\`\``, true)
        embed.addField("__**Günlük Mesaj**__", `\`\`\`js\n${data.dailyMessage} mesaj\`\`\``, true)
        embed.addField("__**Günlük Davet**__", `\`\`\`js\n${dailyInvites}\`\`\``, true)
            interaction.update({ components: [row,row2], embeds: [embed], files: [img]})})} 

            if (interaction.customId === "haftalık") {
        
                let canvas = Canvas.createCanvas(1080, 400),
        
                ctx = canvas.getContext("2d");
                let background = await Canvas.loadImage("https://media.discordapp.net/attachments/1080865598327750806/1080865646994280568/sexxxxx.png");
                ctx.drawImage(background, 0, 0, 1080, 400);
                ctx.textAlign = 'center';
                ctx.font = '35px Sans';
                ctx.fillStyle = '#FFFFFF';
                ctx.fillText(`${client.convertDuration(data.dailyVoice)}`, canvas.width / 1.12, 230);
                ctx.font = '35px Sans';
                ctx.fillStyle = '#FFFFFF';
                ctx.fillText(`${client.convertDuration(data.weeklyVoice)}`, canvas.width / 1.12, 290);
                ctx.font = '35px Sans';
                ctx.fillStyle = '#FFFFFF';
                ctx.fillText(`${client.convertDuration(data.monthlyVoice)}`, canvas.width / 1.12, 350);
        
                ctx.textAlign = 'center';
                ctx.font = '35px Sans';
                ctx.fillStyle = '#FFFFFF';
                ctx.fillText(`${data.dailyMessage} msj`, canvas.width / 1.75, 230);
                ctx.font = '35px Sans';
                ctx.fillStyle = '#FFFFFF';
                ctx.fillText(`${data.weeklyMessage} msj`, canvas.width / 1.75, 290);
                ctx.font = '35px Sans';
                ctx.fillStyle = '#FFFFFF';
                ctx.fillText(`${data.monthlyMessage} msj`, canvas.width / 1.75, 350);
        
                ctx.font = '35px Sans';
                ctx.fillStyle = '#FFFFFF';
                ctx.fillText(`${client.convertDuration(data.totalVoice)}`, canvas.width / 4.07, 290);
                ctx.font = '35px Sans';
                ctx.fillStyle = '#FFFFFF';
                ctx.fillText(`${data.totalMessage} msj`, canvas.width / 4.07, 230);
                ctx.font = '35px Sans';
                ctx.fillStyle = '#FFFFFF';
                ctx.fillText(`sg yok bişi`, canvas.width / 4.07, 350);
        
                ctx.font = '50px Sans';
        let member = message.guild.members.cache.get(target.id);
        let nickname = member.displayName == target.username ? "" + target.username + " [Yok] " : member.displayName
        ctx.fillText(`${nickname}`, canvas.width / 4.80, 95);

        
                ctx.font = '28px Sans';
                ctx.fillStyle = '#FFFFFF';
                ctx.fillText(`${moment(target.user.createdAt).format("L")}`, canvas.width / 1.45, 95);
        
                ctx.font = '28px Sans';
                ctx.fillStyle = '#FFFFFF';
                ctx.fillText(`${moment(target.joinedAt).format("L")}`, canvas.width / 1.12, 95);
            
                    const img = new MessageAttachment(canvas.toBuffer(), 'oy.png');

                Database.find({
                    guildID: message.guild.id,
                    inviterID: target.id
                }).sort().exec((err, inviterMembers) => {
                    let dailyInvites = 0;
                    if (inviterMembers.length) {
                        dailyInvites = inviterMembers.filter(x => message.guild.members.cache.has(x.userID) && (Date.now() - message.guild.members.cache.get(x.userID).joinedTimestamp) < 1000 * 60 * 60 * 24).length;
                    };
                    let aylıkinvite = 0;
                    if (inviterMembers.length) {
                        aylıkinvite = inviterMembers.filter(x => message.guild.members.cache.has(x.userID) && (Date.now() - message.guild.members.cache.get(x.userID).joinedTimestamp) < 1000 * 60 * 60 * 24 * 30).length;
                    }
                    let haftalıksexxx = 0;
                    if (inviterMembers.length) {
                        haftalıksexxx = inviterMembers.filter(x => message.guild.members.cache.has(x.userID) && (Date.now() - message.guild.members.cache.get(x.userID).joinedTimestamp) < 1000 * 60 * 60 * 24 * 7).length;
                    }
        
                   
        
        
        
                    
                    
                    let embed = new MessageEmbed()
                    .setColor(client.renk.renksiz)
                    .setFooter(client.ayarlar.footer)
                    .setAuthor({ name: message.author.tag, iconURL: message.author.avatarURL({dynamic: true})})
                    .setImage('attachment://oy.png')
                    .setDescription(`${target} (<@&${target.roles.highest.id}>) üyesinin \` 1 HAFTALIK \` \`${message.guild.name}\` sunucusunda ki toplam ses ve mesaj bilgileri aşağıda belirtilmiştir.\n`)
                embed.addField("__**Haftalık Ses**__", `\`\`\`js\n${client.convertDuration(data.weeklyVoice)}\`\`\``, true)
                embed.addField("__**Haftalık Mesaj**__", `\`\`\`js\n${data.weeklyMessage} mesaj\`\`\``, true)
                embed.addField("__**Haftalık Davet**__", `\`\`\`js\n${haftalıksexxx}\`\`\``, true)
                    interaction.update({ components: [row,row2], embeds: [embed], files: [img]})})}  

                    if (interaction.customId === "aylık") {
                        let canvas = Canvas.createCanvas(1080, 400),
        
                        ctx = canvas.getContext("2d");
                        let background = await Canvas.loadImage("https://media.discordapp.net/attachments/1080865598327750806/1080865646994280568/sexxxxx.png");
                        ctx.drawImage(background, 0, 0, 1080, 400);
                        ctx.textAlign = 'center';
                        ctx.font = '35px Sans';
                        ctx.fillStyle = '#FFFFFF';
                        ctx.fillText(`${data.dailyMessage} msj`, canvas.width / 1.75, 230);
                        ctx.font = '35px Sans';
                        ctx.fillStyle = '#FFFFFF';
                        ctx.fillText(`${data.weeklyMessage} msj`, canvas.width / 1.75, 290);
                        ctx.font = '35px Sans';
                        ctx.fillStyle = '#FFFFFF';
                        ctx.fillText(`${data.monthlyMessage} msj`, canvas.width / 1.75, 350);
                
                        ctx.textAlign = 'center';
                        ctx.font = '35px Sans';
                        ctx.fillStyle = '#FFFFFF';
                        ctx.fillText(`${client.convertDuration(data.dailyVoice)}`, canvas.width / 1.12, 230);
                        ctx.font = '35px Sans';
                        ctx.fillStyle = '#FFFFFF';
                        ctx.fillText(`${client.convertDuration(data.weeklyVoice)}`, canvas.width / 1.12, 290);
                        ctx.font = '35px Sans';
                        ctx.fillStyle = '#FFFFFF';
                        ctx.fillText(`${client.convertDuration(data.monthlyVoice)}`, canvas.width / 1.12, 350);
                
                        ctx.font = '35px Sans';
                        ctx.fillStyle = '#FFFFFF';
                        ctx.fillText(`${client.convertDuration(data.totalVoice)}`, canvas.width / 4.07, 290);
                        ctx.font = '35px Sans';
                        ctx.fillStyle = '#FFFFFF';
                        ctx.fillText(`${data.totalMessage} msj`, canvas.width / 4.07, 230);
                        ctx.font = '35px Sans';
                        ctx.fillStyle = '#FFFFFF';
                        ctx.fillText(`sg yok bişi`, canvas.width / 4.07, 350);
                
                        ctx.font = '50px Sans';
        let member = message.guild.members.cache.get(target.id);
        let nickname = member.displayName == target.username ? "" + target.username + " [Yok] " : member.displayName
        ctx.fillText(`${nickname}`, canvas.width / 4.80, 95);

                
                        ctx.font = '28px Sans';
                        ctx.fillStyle = '#FFFFFF';
                        ctx.fillText(`${moment(target.user.createdAt).format("L")}`, canvas.width / 1.45, 95);
                
                        ctx.font = '28px Sans';
                        ctx.fillStyle = '#FFFFFF';
                        ctx.fillText(`${moment(target.joinedAt).format("L")}`, canvas.width / 1.12, 95);
                    
                            const img = new MessageAttachment(canvas.toBuffer(), 'oy.png');
        
                        Database.find({
                            guildID: message.guild.id,
                            inviterID: target.id
                        }).sort().exec((err, inviterMembers) => {
                            let dailyInvites = 0;
                            if (inviterMembers.length) {
                                dailyInvites = inviterMembers.filter(x => message.guild.members.cache.has(x.userID) && (Date.now() - message.guild.members.cache.get(x.userID).joinedTimestamp) < 1000 * 60 * 60 * 24).length;
                            };
                            let aylıkinvite = 0;
                            if (inviterMembers.length) {
                                aylıkinvite = inviterMembers.filter(x => message.guild.members.cache.has(x.userID) && (Date.now() - message.guild.members.cache.get(x.userID).joinedTimestamp) < 1000 * 60 * 60 * 24 * 30).length;
                            }
                            let haftalıksexxx = 0;
                            if (inviterMembers.length) {
                                haftalıksexxx = inviterMembers.filter(x => message.guild.members.cache.has(x.userID) && (Date.now() - message.guild.members.cache.get(x.userID).joinedTimestamp) < 1000 * 60 * 60 * 24 * 7).length;
                            }
                
                           
                
                
                
                            
                            
                            let embed = new MessageEmbed()
                            .setColor(client.renk.renksiz)
                            .setFooter(client.ayarlar.footer)
                            .setAuthor({ name: message.author.tag, iconURL: message.author.avatarURL({dynamic: true})})
                            .setImage('attachment://oy.png')
                            .setDescription(`${target} (<@&${target.roles.highest.id}>) üyesinin \` 1 AYLIK \` \`${message.guild.name}\` sunucusunda ki toplam ses ve mesaj bilgileri aşağıda belirtilmiştir.\n`)
                        embed.addField("__**1 Aylık Ses**__", `\`\`\`js\n${client.convertDuration(data.monthlyVoice)}\`\`\``, true)
                        embed.addField("__**1 Aylık Mesaj**__", `\`\`\`js\n${data.monthlyMessage} mesaj\`\`\``, true)
                        embed.addField("__**1 Aylık Davet**__", `\`\`\`js\n${aylıkinvite}\`\`\``, true)
                            interaction.update({ components: [row,row2], embeds: [embed], files: [img]})})}  
})})




        })
        function yetkiliStat(data, parentArray, yasaklıArray) {
            let obje = 0;
            if (data) {
                parentArray.forEach(parentID => {
                    let ekle = 0;
                    message.guild.channels.cache.filter(channel => channel.parentID == parentID).forEach(channel => {
                        if (!yasaklıArray.includes(channel.id)) ekle += (data ? (data[channel.id] || 0) : {});
                    })
                    obje = ekle
                })
                return obje
            } else return obje
        }
    }
    

exports.conf = {
    aliases: ["ramalstat"]
};
exports.help = {
    name: 'stats'
};


function yuzdelik(currentXP, requiredXP, maxWidth) {
    let miktar = currentXP;
    let istenen = requiredXP;
    return parseInt((miktar / istenen) * 100);
}
function getProgressBarWidth(currentXP, requiredXP, maxWidth) {
    if ((currentXP+0.1) > requiredXP) return maxWidth;

    let width = currentXP <= 0 ? 0 : ((currentXP+0.1) * maxWidth) / requiredXP;
    if (width > maxWidth) width = maxWidth;
    return width;
}
function progressBar(value, maxValue, size) {
    const percentage = value < 0 ? 0 : value >= maxValue ? 100 / 100 : value / maxValue;
    const progress = Math.round((size * percentage));
    const emptyProgress = size - progress;
    const progressText = `${client.emojis.cache.find(x => x.name == "ortabar")}`.repeat(progress);
    const emptyProgressText = `${client.emojis.cache.find(x => x.name == "griortabar")}`.repeat(emptyProgress);
    const bar = `${value ? client.emojis.cache.find(x => x.name == "solbar") : client.emojis.cache.find(x => x.name == "baslangicbar")}` + progressText + emptyProgressText + `${emptyProgress == 0 ? `${client.emojis.cache.find(x => x.name === "bitisbar")}` : `${client.emojis.cache.find(x => x.name === "gribitisbar")}`}`;
    return bar;
};

