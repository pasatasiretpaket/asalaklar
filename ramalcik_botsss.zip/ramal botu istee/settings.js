﻿const settings = {

    "MongoDB": "",//mongo url gir
    "commandChannel": ["1077537506389655596"],
     "basvuruLog": "",//elleme boş dursun burası
     "chatMesajı": "-member-, Aramıza hoş geldiniz! Rol seçim odalarından rolleriniz almayı unutmayın iyi eğlenceler.",
     "CEZA_PUAN_KANAL": "1064216095948542003",
     "CEZA_PUAN_SYSTEM": false,
     "RegisterParent": "Kayıt",// register kategorisinin id sini gir

     "MODERASYON": "", // App mod botu
     "STATS": "", // Stats stat botu
     "EXECUTIVE": "", // İnfinity yönetim bptu

     "prefix": [".", "!"],
     "botSesID": "1077537506855231538",//bor ses kanalı id
     "sunucuId": "1077537506389655593",//sunucu id
     "sahip": ["962417173043753022"],
     "guildOwner": ["962417173043753022"],
     "footer": "Kalp Kalmadı Bizde",//elleme
     "readyFooter": ["Değer Mi"]//çoğaltılabilir.
 }
 
    module.exports = settings;