
const { MessageEmbed, MessageActionRow, MessageSelectMenu, MessageButton} = require('discord.js');
const conf = client.ayarlar
let mongoose = require("mongoose");
let sunucuayar = require("../../models/sunucuayar");
let puansystem = require("../../models/puansystem");
module.exports.run = async (client, message, args, durum, kanal) => {
	if (!message.guild) return;
    
    if (message.guild.ownerId === message.author.id || conf.sahip.some(member => message.author.id === member) || durum) {
        let embed2 = new MessageEmbed()
        .setColor(client.renk.renksiz)
        .setAuthor(message.author.tag, message.author.avatarURL({
            dynamic: true
        }))
        .setFooter(conf.footer)
        .setDescription(`:tada: \`${message.guild.name}\` Sunucusunun Yönetim Paneline Hoş Geldiniz. \n Bu menüden botunuzun tüm ayarlarını gerçekleştirebilirsiniz. \nSunucu ayarları, Ve Bot içi Kurulumları tamamlaya Bilirsin. \n`)

        const row = new MessageActionRow().addComponents(
            new MessageSelectMenu()
              .setPlaceholder('Bot Kurulumuna Başla')
              .setCustomId('kurulumselect')
              .addOptions([
              {
                    label: "Server Kurulum",
                    description: "Server Kurulum Görüntüle!",
                    value: "genel",
                    emoji: "987402552427561042"
              },
              { 
                  label: "Kanal Kurulum",
                  value: "kanal",
                  description: "Kanal Kurulum Görüntüle!",
                  emoji: "987402552427561042"

              },
              { 
                label: "Rol Kurulum",
                value: "rol",
                description: "Rol Kurulum Görüntüle!",
                emoji: "987402552427561042"

              },
              { 
                label: "Perm Kurulum",
                value: "perm",
                description: "Perm Kurulum Görüntüle!",
                emoji: "987402552427561042"

              },
              { 
                label: "Görev Kurulum",
                value: "görev",
                description: "Görev Kurulum Görüntüle!",
                emoji: "987402552427561042"

              },
              { 
                label: "Kapat",
                value: "closeMenu",
                emoji: "921403309112303637"
              }
            ])
            );
        
        message.channel.send({ components: [row], embeds: [embed2] }).then(async m => {
            let collector = m.createMessageComponentCollector({ filter: row => row.member.user.id === message.author.id, max: 5, time: 999999, errors: ['time'] })
            collector.on('collect', async (interaction) => {
                
        if(interaction.values == "genel") {
            let data = await sunucuayar.findOne({guildID: message.guild.id});
            const Embed = new MessageEmbed().setColor(client.renk.renksiz).setFooter(client.ayarlar.footer)
            .setAuthor(message.author.tag, message.author.avatarURL({
                dynamic: true
            }))
            .setDescription(`\`\`\`fix\nServer Kurulum\`\`\`
\`.kur tag <serverTAG>\` (${data.TAG ? data.TAG : "\`Kapalı\`"})
\`.kur tag2 <serverTAG2>\` (${data.TAG2 ? data.TAG2 : "\`Kapalı\`"})
\`.kur link <serverLINK>\` (${data.LINK ? data.LINK : "\`Kapalı\`"})
\`.kur gkv @safedMember\` (${data.GKV.length > 0 ? data.GKV.map(x => `<@${x}>`).slice(0, 5).join(","): "\`Kapalı\`"})
\`.kur grv @safedRoles\` (${data.GRV.length > 0 ? data.GRV.map(x => `<@&${x}>`).slice(0, 5).join(",") : "\`Kapalı\`"})
`)
            
        interaction.update({ components: [row], embeds: [Embed] }).then(e => setTimeout(() => button.message.delete().catch(() => { }), 999999))}		 
        
        if(interaction.values == "kanal") {
            let data = await sunucuayar.findOne({guildID: message.guild.id});
            let data2 = await puansystem.findOneAndUpdate({guildID: message.guild.id}, {guildID: message.guild.id}, {upsert: true, setDefaultsOnInsert: true}).exec()
            let embed3 = new MessageEmbed().setColor(client.renk.renksiz).setFooter(client.ayarlar.footer)
            .setAuthor(message.author.tag, message.author.avatarURL({
                dynamic: true
            }))
            embed3.setDescription(`\`\`\`fix\nKanal Kurulum\`\`\`
\`.kur chat #chatChannel\` (${data.CHAT != "1" ? `<#${data.CHAT}>` : "\`Kapalı\`"})
\`.kur register #registerChannel\` (${data.REGISTER != "1" ? `<#${data.REGISTER}>` : "\`Kapalı\`"})
\`.kur taglog #taglogChannel\` (${data.TAGLOG != "1" ? `<#${data.TAGLOG}>` : "\`Kapalı\`"})
\`.kur rules #rulesChannel\` (${data.RULES != "1" ? `<#${data.RULES}>` : "\`Kapalı\`"})
\`.kur sleep #sleepChannel\` (${data.SLEEP != "1" ? `<#${data.SLEEP}>` : "\`Kapalı\`"})
\`.kur category ID\`
\`.kur rol-ver-log #roleLogChannel\` (${data.ROLEChannel != "1" ? `<#${data.ROLEChannel}>`: "\`Kapalı\`"})
──────────────────────────────────────
\`${conf.prefix[0]}kur2 public #category\` (\`Saat Başı 20 Puan\`) (${data2.PublicKanallar.Id.length > 0 ? data2.PublicKanallar.Id.map(x => message.guild.channels.cache.get(x)) : "Kapalı"})
\`${conf.prefix[0]}kur2 game #category\` (\`Saat Başı 5 Puan\`) (${data2.GameKanallar.Id.length > 0 ? data2.GameKanallar.Id.map(x => message.guild.channels.cache.get(x)) : "Kapalı"})
\`${conf.prefix[0]}kur2 register #category\` (\`Saat Başı 10 Puan\`) (${data2.KayitKanallar.Id.length > 0 ? data2.KayitKanallar.Id.map(x => message.guild.channels.cache.get(x)) : "Kapalı"})
\`${conf.prefix[0]}kur2 streamer #category\` (\`Saat Başı 10 Puan\`) (${data2.StreamKanallar.Id.length > 0 ? data2.StreamKanallar.Id.map(x => message.guild.channels.cache.get(x)) : "Kapalı"})
\`${conf.prefix[0]}kur2 secret #category\` (\`Saat Başı 2 Puan\`) (${data2.SecretKanallar.Id.length > 0 ? data2.SecretKanallar.Id.map(x => message.guild.channels.cache.get(x)) : "Kapalı"})
\`${conf.prefix[0]}kur2 sleeping #category\` (\`Saat Başı 3 Puan\`) (${data2.SleepingKanal.Id > 0 ? message.guild.channels.cache.get(data2.SleepingKanal.Id) : "Kapalı"})
\`${conf.prefix[0]}kur2 alone #category\` (\`Saat Başı 2 Puan\`) (${data2.AloneKanallar.Id.length > 0 ? data2.AloneKanallar.Id.map(x => message.guild.channels.cache.get(x)) : "Kapalı"})
\`${conf.prefix[0]}kur2 terapi #category\` (\`Saat Başı 7 Puan\`) (${data2.TerapiKanallar.Id.length > 0 ? data2.TerapiKanallar.Id.map(x => message.guild.channels.cache.get(x)) : "Kapalı"})
\`${conf.prefix[0]}kur2 sorunçözme #category\` (\`Saat Başı 7 Puan\`) (${data2.SorunCozmeKanallar.Id.length > 0 ? data2.SorunCozmeKanallar.Id.map(x => message.guild.channels.cache.get(x)) : "Kapalı"})
\`${conf.prefix[0]}kur2 müzik #category\` (\`Saat Başı 2 Puan\`) (${data2.Müzik.Id.length > 0 ? data2.Müzik.Id.map(x => message.guild.channels.cache.get(x)) : "Kapalı"})
\`${conf.prefix[0]}kur2 toplantı #category\` (\`Saat Başı 10 Puan\`) (${data2.Toplantı.Id.length > 0 ? data2.Toplantı.Id.map(x => message.guild.channels.cache.get(x)) : "Kapalı"})
\`${conf.prefix[0]}kur2 mesaj #channel\` (\`Mesaj Başı 0.08 Puan\`) (${data2.MesajKanallar.Id.length > 0 ? data2.MesajKanallar.Id.map(x => message.guild.channels.cache.get(x)) : "Kapalı"})



`)
                interaction.update({ components: [row], embeds: [embed3] }).then(e => setTimeout(() => button.message.delete().catch(() => { }), 15000))
            }
          
            if(interaction.values == "rol") {
                let data = await sunucuayar.findOne({guildID: message.guild.id});
                let embed4 = new MessageEmbed().setColor(client.renk.renksiz).setFooter(client.ayarlar.footer)
                .setAuthor(message.author.tag, message.author.avatarURL({
                    dynamic: true
                }))
                embed4.setDescription(`\`\`\`fix\nRol Kurulum\`\`\`
                \`.kur unregister @unregisterRole @unregisterRole2\` ${data.UNREGISTER.length > 0 ? `${data.UNREGISTER.map(x => `<@&${x}>`).join(",")}` : "\`Kapalı\`"}
                \`.kur man @manRole @manRole2\` ${data.MAN.length > 0 ? `${data.MAN.map(x => `<@&${x}>`).join(",")}` : "\`Kapalı\`"}
                \`.kur woman @womanRole @womanRole2\` ${data.WOMAN.length > 0 ? `${data.WOMAN.map(x => `<@&${x}>`).join(",")}` : "\`Kapalı\`"}
                \`.kur team @teamRole\` ${data.TEAM != "1" ? `<@&${data.TEAM}>` : "\`Kapalı\`"}
                \`.kur boost @boostRole\` ${data.BOOST != "1" ? `<@&${data.BOOST}>` : "\`Kapalı\`"}
                \`.kur jail @jailRole\` ${data.JAIL != "1" ? `<@&${data.JAIL}>` : "\`Kapalı\`"}
                \`.kur reklam @reklamRole\` ${data.REKLAM != "1" ? `<@&${data.REKLAM}>` : "\`Kapalı\`"}
                \`.kur supheli @supheliRole\` ${data.SUPHELI != "1" ? `<@&${data.SUPHELI}>` : "\`Kapalı\`"}
                \`.kur bantag @banTagRole\` ${data.BANTAG != "1" ? `<@&${data.BANTAG}>` : "\`Kapalı\`"}
                \`.kur mute @mutedRole\` ${data.MUTED != "1" ? `<@&${data.MUTED}>` : "\`Kapalı\`"}
                \`.kur vmute @vmutedRole\` ${data.VMUTED != "1" ? `<@&${data.VMUTED}>` : "\`Kapalı\`"}
                \`.kur registerauthorized @registerAuthorized\` ${data.REGISTERAuthorized.length  > 0 ? `${data.REGISTERAuthorized.map(x => `<@&${x}>`).join(",")}` : "\`Kapalı\`"}
                \`.kur globalrol @globalrol1 @globalrol2\` ${data.COMMANDAuthorized.length  > 0 ? `${data.COMMANDAuthorized.map(x => `<@&${x}>`).join(",")}` : "\`Kapalı\`"}
                \`.kur enaltrol @enaltyetkilirolü\` ${data.EnAltYetkiliRol ? `<@&${data.EnAltYetkiliRol}>` : "\`Kapalı\`"}
                \`.kur ustytler @ustYt @ustYt2 @ustYt3\` ${data.UstYetkiliRol.length  > 0 ? `${data.UstYetkiliRol.map(x => `<@&${x}>`).join(",")}` : "\`Kapalı\`"}
                \`.kur ust1 @ustYetkiliRol\` ${data.Ust1YetkiliRol ? `<@&${data.Ust1YetkiliRol}>` : "\`Kapalı\`"}
                \`.kur ust2 @ust2YetkiliRol\` ${data.Ust2YetkiliRol ? `<@&${data.Ust2YetkiliRol}>` : "\`Kapalı\`"}
                \`.kur ust3 @ust3YetkiliRol\` ${data.Ust3YetkiliRol ? `<@&${data.Ust3YetkiliRol}>` : "\`Kapalı\`"}`)
                    interaction.update({ components: [row], embeds: [embed4] }).then(e => setTimeout(() => button.message.delete().catch(() => { }), 15000))
                }
                if(interaction.values == "perm") {
                    let data = await sunucuayar.findOne({guildID: message.guild.id});
                    let embed4 = new MessageEmbed().setColor(client.renk.renksiz).setFooter(client.ayarlar.footer)
                    .setAuthor(message.author.tag, message.author.avatarURL({
                        dynamic: true
                    }))
                    embed4.setDescription(`\`\`\`fix\nPerm Kurulum\`\`\`
Mute Setup: .mute kur yetki,kanal,limit                    
Mute Limit: **${data.MUTELimit}**
Mute Kanal: <#${data.MUTEChannel}>
Yetkililer: ${data.MUTEAuthorized.map(x => `<@&${x}>`)}

VMute Setup: .vmute kur yetki,kanal,limit               
VMute Limit: **${data.VMuteLimit}**
VMute Kanal: <#${data.VMUTEChannel}>
Yetkililer: ${data.VMUTEAuthorized.map(x => `<@&${x}>`)}

Jail Setup: .jail kur yetki,kanal,limit               
Jail Limit: **${data.JAILLimit}**
Jail Kanal: <#${data.JAILChannel}>
Yetkililer: ${data.JAILAuthorized.map(x => `<@&${x}>`)}

Reklam Setup: .reklam kur yetki,kanal,limit 
Reklam Limit: **${data.REKLAMLimit}**
Reklam Kanal: <#${data.REKLAMChannel}>
Yetkililer: ${data.REKLAMAuthorized.map(x => `<@&${x}>`)}

Ban Setup: .ban kur yetki,kanal,limit 
Ban Limit: **${data.BANLimit}**
Ban Kanal: <#${data.BANChannel}>
Yetkililer: ${data.BANAuthorized.map(x => `<@&${x}>`)}

Invıte Kanal: .invite kanal #kanal
Kayıt Kanal: <#${data.REGISTER}>
Yetkililer: ${data.REGISTERAuthorized.map(x => `<@&${x}>`)}



                `)
                        interaction.update({ components: [row], embeds: [embed4] }).then(e => setTimeout(() => button.message.delete().catch(() => { }), 15000))
                    }
                    if(interaction.values == "görev") {
                        let data = await puansystem.findOneAndUpdate({guildID: message.guild.id}, {guildID: message.guild.id}, {upsert: true, setDefaultsOnInsert: true}).exec()
                        let embed4 = new MessageEmbed().setColor(client.renk.renksiz).setFooter(client.ayarlar.footer)
                        .setAuthor(message.author.tag, message.author.avatarURL({
                            dynamic: true
                        }))
                        embed4.setDescription(`\`\`\`fix\nGörev Kurulum\`\`\`
                        \`${conf.prefix[0]}kur2 category\` (${data.DailyMission.category.length > 0 ? data.DailyMission.category.map(x => message.guild.channels.cache.get(x)) : "Kapalı"})
                        \`${conf.prefix[0]}kur2 messagechannel\` (${data.DailyMission.messageChannel.length > 0 ? data.DailyMission.messageChannel.map(x => message.guild.channels.cache.get(x)) : "Kapalı"})
                        \`${conf.prefix[0]}kur2 unchannel\` (${data.DailyMission.unChannel.length > 0 ? data.DailyMission.unChannel.map(x => message.guild.channels.cache.get(x)) : "Kapalı"})
                        \`${conf.prefix[0]}kur2 logchannel\` (${data.DailyMission.logChannel ? message.guild.channels.cache.get(data.DailyMission.logChannel) : "Kapalı"})
                        \`\`\`fix\nOto Rank Kurulum\`\`\`
                        \`${conf.prefix[0]}kur2 autorankup\` (**${data.AutoRankUP.Type == true ? "Aktif": "Kapalı"}**)
                        \`${conf.prefix[0]}kur2 autorankuplog #channel\`
                        \`${conf.prefix[0]}kur2 autorankupsabitrol ID\` (${data.AutoRankUP.sabitROL ? `<@&${data.AutoRankUP.sabitROL}>` : "**Kapalı**"})
                        \`\`\`fix\nLevel Sistem Kurulum\`\`\`
                        \`${conf.prefix[0]}kur2 levelup\` (**${data.LevelSystem.Type == true ? "Aktif": "Kapalı"}**)
                        \`${conf.prefix[0]}kur2 leveluplog #channel\`
                        \`\`\`fix\nRank Puan Kurulum\`\`\`
                        \`${conf.prefix[0]}kur2 rankpoint ilkrol ikincirol puan\`
                        \`\`\`fix\nOto Kayıt Kurulum\`\`\`
                        \`${conf.prefix[0]}kur2 otologin\` (**${data.AutoLogin.Type == true ? "Aktif": "Kapalı"}**)
    
                    `)
                            interaction.update({ components: [row], embeds: [embed4] }).then(e => setTimeout(() => button.message.delete().catch(() => { }), 15000))
                        }
                    if(interaction.values == "closeMenu") {
                        message.react(client.emojis.cache.find(x => x.name === "tik"))
                        interaction.message.delete()}
            })})
    } else return
}

exports.conf = {
    aliases: ["setupB"]
}
exports.help = {
    name: 'Setup'
}