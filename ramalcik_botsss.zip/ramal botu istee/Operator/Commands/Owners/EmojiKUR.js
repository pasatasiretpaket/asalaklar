const { MessageEmbed } = require("discord.js");
const Discord = require('discord.js');

exports.run = async (client, message, args, durum, kanal) => {
  if (!message.guild) return;
  let guild = message.guild;
  if (!client.ayarlar.sahip.some(x => x === message.author.id)) return
	if(args[0] === "kur" || args[0] === "kurulum") {
    
    let onay = "https://cdn.discordapp.com/emojis/1014542762915414099.gif?size=96&quality=lossless";
    let iptal = "https://cdn.discordapp.com/emojis/1014542755722186863.gif?size=96&quality=lossless"; 
    let iptal2 = "https://cdn.discordapp.com/emojis/995761605210026094.png?v=1"; 
    let yildiz = "https://cdn.discordapp.com/emojis/991357112083021964.gif?v=1";
    let ramal_vmute = "https://cdn.discordapp.com/attachments/811975658963992647/812894209706950656/sesmuteat.png";
    let ramal_mute = "https://cdn.discordapp.com/attachments/811975658963992647/812894244632788992/muteat.png";
    let ramal_vunmute = "https://cdn.discordapp.com/attachments/811975658963992647/812894192530751518/sesmuteac.png";
    let ramal_unmute = "https://cdn.discordapp.com/attachments/811975658963992647/812894234242973716/muteac.png";
    let ramal_bitisbar = "https://cdn.discordapp.com/emojis/1001111608367521852.png?v=1";
    let ramal_solbar =  "https://cdn.discordapp.com/emojis/1001111603757981777.png?v=1";
    let ramal_ortabar = "https://cdn.discordapp.com/emojis/1001111605351825408.png?v=1";
    let ramal_ban = "https://cdn.discordapp.com/emojis/946070076271001670.png?v=1";
    let ramal_jail = "https://cdn.discordapp.com/emojis/939679320551616543.png?v=1";
    let ramal_baslangicbar = "https://cdn.discordapp.com/emojis/1001111610221395988.png?v=1";
    let ramal_gribitisbar = "https://cdn.discordapp.com/emojis/1001111614667378748.png?v=1";
    let ramal_griortabar = "https://cdn.discordapp.com/emojis/1001111612905754674.png?v=1";
    let ramal_afk = "https://cdn.discordapp.com/emojis/776764964009672704.png?v=1"
    let ramal_carpi = "https://cdn.discordapp.com/attachments/1008427922165608498/1010853028120764456/984066937506127939.gif"
    let ramal_okey = "https://cdn.discordapp.com/attachments/1008825485075153008/1010854182225444875/995390996571496448.gif"
    let ramal_info = "https://cdn.discordapp.com/emojis/1028355470622216272.webp?size=96&quality=lossless"
    let ramal_cikis = "https://cdn.discordapp.com/emojis/1023617059973767279.webp?size=96&quality=lossless"
    let ramal_giris = "https://cdn.discordapp.com/emojis/1023581888390119585.webp?size=96&quality=lossless"
    let ramal_security = "https://cdn.discordapp.com/emojis/921047804883918858.gif?size=96&quality=lossless"
    let ramal_sıfır = "https://cdn.discordapp.com/emojis/1008414524241612910.gif?size=96&quality=lossless"
    let ramal_bir = "https://cdn.discordapp.com/emojis/1008414433699184771.gif?size=96&quality=lossless"
    let ramal_iki = "https://cdn.discordapp.com/emojis/1008414448769314836.gif?size=96&quality=lossless"
    let ramal_uc = "https://cdn.discordapp.com/emojis/1008414464221126696.gif?size=96&quality=lossless"
    let ramal_dort = "https://cdn.discordapp.com/emojis/1008414477848424549.gif?size=96&quality=lossless"
    let ramal_bes = "https://cdn.discordapp.com/emojis/1008414492213911562.gif?size=96&quality=lossless"
    let ramal_altı = "https://cdn.discordapp.com/emojis/1008414508458447012.gif?size=96&quality=lossless"
    let ramal_yedi = "https://cdn.discordapp.com/emojis/1008416222871814325.gif?size=96&quality=lossless"
    let ramal_sekiz = "https://cdn.discordapp.com/emojis/1008416245655281715.gif?size=96&quality=lossless"
    let ramal_dokuz = "https://cdn.discordapp.com/emojis/1008416206367244398.gif?size=96&quality=lossless"

    guild.emojis.create(ramal_vmute, "ramal_vmute").then(emoji => message.channel.send(`Emrinizle ${emoji.name} Adında Emojiyi Oluşturdum (${emoji})`)).catch(console.error);
    guild.emojis.create(ramal_mute, "ramal_mute").then(emoji => message.channel.send(`Emrinizle ${emoji.name} Adında Emojiyi Oluşturdum (${emoji})`)).catch(console.error);
    guild.emojis.create(ramal_vunmute, "ramal_vunmute").then(emoji => message.channel.send(`Emrinizle ${emoji.name} Adında Emojiyi Oluşturdum (${emoji})`)).catch(console.error);
    guild.emojis.create(ramal_unmute, "ramal_unmute").then(emoji => message.channel.send(`Emrinizle ${emoji.name} Adında Emojiyi Oluşturdum (${emoji})`)).catch(console.error);
    guild.emojis.create(onay, "ramal_tik").then(emoji => message.channel.send(`Emrinizle ${emoji.name} Adında Emojiyi Oluşturdum (${emoji})`)).catch(console.error);
    guild.emojis.create(iptal, "ramal_carpi").then(emoji => message.channel.send(`Emrinizle ${emoji.name} Adında Emojiyi Oluşturdum (${emoji})`)).catch(console.error);
    guild.emojis.create(iptal2, "ramal_cancel").then(emoji => message.channel.send(`Emrinizle ${emoji.name} Adında Emojiyi Oluşturdum (${emoji})`)).catch(console.error);
    guild.emojis.create(ramal_baslangicbar, "ramal_baslangicbar").then(emoji => message.channel.send(`Emrinizle ${emoji.name} Adında Emojiyi Oluşturdum (${emoji})`)).catch(console.error);
    guild.emojis.create(ramal_bitisbar, "ramal_bitisbar").then(emoji => message.channel.send(`Emrinizle ${emoji.name} Adında Emojiyi Oluşturdum (${emoji})`)).catch(console.error);
    guild.emojis.create(ramal_solbar, "ramal_solbar").then(emoji => message.channel.send(`Emrinizle ${emoji.name} Adında Emojiyi Oluşturdum (${emoji})`)).catch(console.error);
    guild.emojis.create(ramal_ortabar, "ramal_ortabar").then(emoji => message.channel.send(`Emrinizle ${emoji.name} Adında Emojiyi Oluşturdum (${emoji})`)).catch(console.error);
    guild.emojis.create(ramal_gribitisbar, "ramal_gribitisbar").then(emoji => message.channel.send(`Emrinizle ${emoji.name} Adında Emojiyi Oluşturdum (${emoji})`)).catch(console.error);
    guild.emojis.create(ramal_griortabar, "ramal_griortabar").then(emoji => message.channel.send(`Emrinizle ${emoji.name} Adında Emojiyi Oluşturdum (${emoji})`)).catch(console.error);
    guild.emojis.create(yildiz, "ramal_imaj").then(emoji => message.channel.send(`Emrinizle ${emoji.name} Adında Emojiyi Oluşturdum (${emoji})`)).catch(console.error);
    guild.emojis.create(ramal_ban, "ramal_ban").then(emoji => message.channel.send(`Emrinizle ${emoji.name} Adında Emojiyi Oluşturdum (${emoji})`)).catch(console.error);
    guild.emojis.create(ramal_jail, "ramal_jail").then(emoji => message.channel.send(`Emrinizle ${emoji.name} Adında Emojiyi Oluşturdum (${emoji})`)).catch(console.error);
    guild.emojis.create(ramal_afk, "ramal_afk").then(emoji => message.channel.send(`Emrinizle ${emoji.name} Adında Emojiyi Oluşturdum (${emoji})`)).catch(console.error); 
    guild.emojis.create(ramal_carpi, "ramal_carpii").then(emoji => message.channel.send(`Emrinizle ${emoji.name} Adında Emojiyi Oluşturdum (${emoji})`)).catch(console.error);
    guild.emojis.create(ramal_okey, "ramal_okey").then(emoji => message.channel.send(`Emrinizle ${emoji.name} Adında Emojiyi Oluşturdum (${emoji})`)).catch(console.error);
    guild.emojis.create(ramal_info, "ramal_info").then(emoji => message.channel.send(`Emrinizle ${emoji.name} Adında Emojiyi Oluşturdum (${emoji})`)).catch(console.error);
    guild.emojis.create(ramal_cikis, "ramal_cikis").then(emoji => message.channel.send(`Emrinizle ${emoji.name} Adında Emojiyi Oluşturdum (${emoji})`)).catch(console.error);
    guild.emojis.create(ramal_giris, "ramal_giris").then(emoji => message.channel.send(`Emrinizle ${emoji.name} Adında Emojiyi Oluşturdum (${emoji})`)).catch(console.error);
    guild.emojis.create(ramal_security, "ramal_security").then(emoji => message.channel.send(`Emrinizle ${emoji.name} Adında Emojiyi Oluşturdum (${emoji})`)).catch(console.error);
    guild.emojis.create(ramal_sıfır, "ramal_sıfır").then(emoji => message.channel.send(`Emrinizle ${emoji.name} Adında Emojiyi Oluşturdum (${emoji})`)).catch(console.error);
    guild.emojis.create(ramal_bir, "ramal_bir").then(emoji => message.channel.send(`Emrinizle ${emoji.name} Adında Emojiyi Oluşturdum (${emoji})`)).catch(console.error);
    guild.emojis.create(ramal_iki, "ramal_iki").then(emoji => message.channel.send(`Emrinizle ${emoji.name} Adında Emojiyi Oluşturdum (${emoji})`)).catch(console.error);
    guild.emojis.create(ramal_uc, "ramal_uc").then(emoji => message.channel.send(`Emrinizle ${emoji.name} Adında Emojiyi Oluşturdum (${emoji})`)).catch(console.error);
    guild.emojis.create(ramal_dort, "ramal_dort").then(emoji => message.channel.send(`Emrinizle ${emoji.name} Adında Emojiyi Oluşturdum (${emoji})`)).catch(console.error);
    guild.emojis.create(ramal_bes, "ramal_bes").then(emoji => message.channel.send(`Emrinizle ${emoji.name} Adında Emojiyi Oluşturdum (${emoji})`)).catch(console.error);
    guild.emojis.create(ramal_altı, "ramal_altı").then(emoji => message.channel.send(`Emrinizle ${emoji.name} Adında Emojiyi Oluşturdum (${emoji})`)).catch(console.error);
    guild.emojis.create(ramal_yedi, "ramal_yedi").then(emoji => message.channel.send(`Emrinizle ${emoji.name} Adında Emojiyi Oluşturdum (${emoji})`)).catch(console.error);
    guild.emojis.create(ramal_sekiz, "ramal_sekiz").then(emoji => message.channel.send(`Emrinizle ${emoji.name} Adında Emojiyi Oluşturdum (${emoji})`)).catch(console.error);
    guild.emojis.create(ramal_dokuz, "ramal_dokuz").then(emoji => message.channel.send(`Emrinizle ${emoji.name} Adında Emojiyi Oluşturdum (${emoji})`)).catch(console.error);
 return;
  };
};

exports.conf = {
    enabled: true,
    guildOnly: false,
    aliases: ['emojis'],
    permLevel: 4
  };
  
  exports.help = {
    name: 'emoji',
    description: "Sunucuda komut denemeye yarar",
    usage: 'eval <kod>',
    kategori: "Bot Yapımcısı"
  };
  