
const {MessageEmbed, MessageActionRow, MessageSelectMenu, MessageButton} = require('discord.js');
const conf = client.ayarlar
let teyit = require("../../models/teyit");
let sunucuayar = require("../../models/sunucuayar");
let otokayit = require("../../models/otokayit");
let randMiss = require("../../models/randomMission")
let puansystem = require("../../models/puansystem");
let limit = new Map();
let sure = new Map();
const ms = require("ms");
module.exports.run = async (client, message, args, durum, kanal) => {
    if (!message.guild) return;
    let data = await sunucuayar.findOne({
        guildID: message.guild.id
    });
    let target = message.mentions.members.first() || message.guild.members.cache.get(args[0]);

    let erkekRol = data.MAN;
    let kadinRol = data.WOMAN;
    let unRegisterRol = data.UNREGISTER;
    let registerChannel = data.REGISTERChannel;
    let tag = data.TAG;
    let tag2 = data.TAG2;
    let kayitSorumlusu = data.REGISTERAuthorized;
    let ekipRol = data.TEAM;
    let supheliRol = data.SUPHELI;
    let chatKANAL = data.CHAT;
    let boost = data.BOOST
    if (!message.guild.roles.cache.get(erkekRol[0]) &&
        !message.guild.roles.cache.get(kadinRol[0]) &&
        !message.guild.roles.cache.get(unRegisterRol[0]) &&
        !message.guild.roles.cache.get(kayitSorumlusu[0]) &&
        !client.channels.cache.get(registerChannel) &&
        !tag && !tag2) return message.reply(`Lütfen kurulum sistemini tamamen bitiriniz \`${conf.prefix[0]}setup help\``);
        if (message.member.permissions.has(8n) || message.member.roles.cache.some(e => kayitSorumlusu.some(x => x == e)) || message.member.permissions.has(8n)) {

        let kntrl = limit.get(message.author.id)
        let sre = sure.get(message.author.id)
        if (kntrl >= 6 && sre > Date.now() && !message.member.permissions.has(8) && !message.member.roles.cache.some(rol => data.MUTEAuthorized.includes(rol.id))) {
message.channel.send("Kısa Süre İçerisinde **6** ve daha fazla kayıt işlemi gerçekleştirdiğin için yetkilerin alındı.")
            return message.member.roles.remove(user.roles.cache.filter(rol => message.guild.roles.cache.get(data.TEAM).position <= rol.position && !rol.managed))
        }
        if (!sre) {
            sure.set(message.author.id, Date.now()+ms("30s"))
        }
        
        limit.set(message.author.id, (limit.get(message.author.id) || 0) +1)
        setTimeout(() => {
            limit.delete(message.author.id)
            sure.delete(message.author.id)
        }, ms("30s"));
    
        if (!target) return message.channel.send(`${client.emojis.cache.find(x => x.name === "ramal_carpi")} \`Üye belirtilmedi\` .e/k @ramal/id ramal 20`);
        unreg = unRegisterRol;
        if (!args[1]) return message.channel.send(`${client.emojis.cache.find(x => x.name === "ramal_carpi")} \`İsim belirtilmedi\` .e/k @ramal/id ramal 20`);

        let name = args[1][0].toUpperCase() + args[1].substring(1);
        let age = Number(args[2]);
        if (!age) message.channel.send(`${client.emojis.cache.find(x => x.name === "ramal_carpi")} \`Yaş belirtilmedi\` .e/k @ramal/id ramal 20`);
        if (message.member.roles.highest.position <= target.roles.highest.position) return message.reply(`Belirttiğin kişi senden üstün veya onunla aynı yetkidesin!`);
        
        if (target.roles.cache.some(rol => erkekRol.includes(rol.id))) return message.channel.send(`${client.emojis.cache.find(x => x.name === "ramal_carpi")} \`Hatalı İşlem.\` Belirttiğin üye zaten sunucumuzda kayıtlı.`);
        if (target.roles.cache.some(rol => kadinRol.includes(rol.id))) return message.channel.send(`${client.emojis.cache.find(x => x.name === "ramal_carpi")} \`Hatalı İşlem.\` Belirttiğin üye zaten sunucumuzda kayıtlı.`);
        await message.guild.members.cache.get(target.id).setNickname(`${target.user.username.includes(tag) ? tag : tag2 ? tag2 : tag} ${name} | ${age}`);

        let autoLogin = await puansystem.findOne({
            guildID: message.guild.id
        });
  
        const button1 = new MessageButton()
        .setCustomId('erkek1')
        .setLabel('Erkek')
        .setStyle('PRIMARY')
        const button = new MessageButton()
        .setCustomId('kız1')
        .setLabel('Kadın')
        .setStyle('DANGER')
        const rowButton = new MessageActionRow().addComponents(button1, button)
        let Embed = new MessageEmbed().setAuthor(message.author.tag, message.author.avatarURL({dynamic: true}))
        message.reply({ embeds:[Embed.setColor(client.renk.renksiz).setDescription(`${target} kişisinin ismi ${name} | ${age} olarak değiştirildi\n`)],components: [rowButton] })
        var filter = (button) => button.user.id === message.author.id;
        const collector = message.channel.createMessageComponentCollector({ filter, time: 30000 })
        collector.on('collect', async (button) => {
            if (button.customId === "erkek1") {
                target.user.username.includes(tag) ? erkekRol.push(ekipRol) : erkekRol = erkekRol;
                await target.roles.remove(unreg).then(async x => {
                    await target.roles.set(target.roles.cache.has(boost) ? [boost, ...erkekRol] : [...erkekRol])
                    let = İsimYascik = `${target.user.username.includes(tag) ? tag : tag2 ? tag2 : tag} ${name} | ${age}`
                    await target.setNickname(`${target.user.username.includes(tag) ? tag : tag2 ? tag2 : tag} ${name} | ${age}`);
                    
                    if (target.roles.cache.some(rol => kadinRol.some(rol2 => rol.id == rol2))) {
                        kadinRol.forEach(async (res, i) => {
                            setTimeout(async () => {
                                await target.roles.remove(res)
                            }, i * 1000);
                        })
                    };
        
                    teyit.findOne({guildID: message.guild.id, victimID: target.id}, (err, sea) => {
                        if(!sea) {
                            let Embed = new MessageEmbed().setAuthor(message.author.tag, message.author.avatarURL({dynamic: true}))
                            button.update({ embeds: [Embed.setColor(client.renk.renksiz).setDescription(`${target} kişisinin ismi ${name} | ${age} olarak değiştirildi\n\n**ERKEK** olarak kayıt edildi!`)] }).then(e => setTimeout(() => e.delete().catch(() => { }), 20000)), message.react(`${client.emojis.cache.find(x => x.name === "tik")}`)
                        }})
                        teyit.findOne({guildID: message.guild.id, victimID: target.id}, (err, res) => {
                        if(!res) {
                        new teyit({guildID: message.guild.id, victimID: target.id, nicknames: [{isimler: `${İsimYascik}`, rol: `Erkek`, execID: message.author.id, date: Date.now()}]}).save()
                        } else {
                        res.nicknames.push({isimler: `${İsimYascik}`,rol: `Erkek`, execID: message.author.id, date: Date.now()})
                        res.save()}})
                        let Embed = new MessageEmbed().setAuthor(message.author.tag, message.author.avatarURL({dynamic: true}))
                        rowButton.components[0].setDisabled(true) 
                        rowButton.components[1].setDisabled(true) 
                        button.update({ embeds: [Embed.setColor(client.renk.renksiz).setDescription(`${target} kişisinin ismi ${name} | ${age} olarak değiştirildi\n\n**ERKEK** olarak kayıt edildi!`)],components: [rowButton] })
                        const button12 = new MessageButton()
                        .setCustomId('hg')
                        .setLabel('Hadi Selam Ver!')
                        .setEmoji("🎉")
                        .setStyle('SECONDARY')
                        const r2owButton = new MessageActionRow().addComponents(button12)
                    client.channels.cache.get(chatKANAL).send({content: client.ayarlar.chatMesajı.replace("-member-", target)}).then(msg => msg.delete({
                        timeout: 1000 * 10
                    }))
                    await randMiss.findOneAndUpdate({ userID: message.member.id, "Mission.MISSION": "teyit" }, { $inc: { Check: 1 } }, { upsert: true });
        
                    client.easyMission(message.author.id, "teyit", 1)
                    client.addAudit(message.author.id, 1, "Erkek");
                   
                })
            } else if (button.customId === "kız1") {
                target.user.username.includes(tag) ? kadinRol.push(ekipRol) : kadinRol = kadinRol;
                await target.roles.remove(unreg).then(async x => {
                    await target.roles.set(target.roles.cache.has(boost) ? [boost, ...kadinRol] : [...kadinRol])
                    let = İsimYascik = `${target.user.username.includes(tag) ? tag : tag2 ? tag2 : tag} ${name} | ${age}`
                    await target.setNickname(`${target.user.username.includes(tag) ? tag : tag2 ? tag2 : tag} ${name} | ${age}`);
                    
                    if (target.roles.cache.some(rol => erkekRol.some(rol2 => rol.id == rol2))) {
                        await erkekRol.forEach(async (res, i) => {
                            setTimeout(async () => {
                                await target.roles.remove(res)
                            }, i * 1000);
                        })
                    };
                    teyit.findOne({guildID: message.guild.id, victimID: target.id}, (err, ramal) => {
                        if(!ramal) {
                            let Embed = new MessageEmbed().setAuthor(message.author.tag, message.author.avatarURL({dynamic: true}))
                            button.update({ embeds: [Embed.setColor(client.renk.renksiz).setDescription(`${target} kişisinin ismi ${name} | ${age} olarak değiştirildi\n\n**KADIN** olarak kayıt edildi!`)] }).then(e => setTimeout(() => e.delete().catch(() => { }), 20000)), message.react(`${client.emojis.cache.find(x => x.name === "tik")}`)
                        }})
                        teyit.findOne({guildID: message.guild.id, victimID: target.id}, (err, res) => {
                        if(!res) {
                        new teyit({guildID: message.guild.id, victimID: target.id, nicknames: [{isimler: `${İsimYascik}`, rol: `Kadın`, execID: message.author.id, date: Date.now()}]}).save()
                        } else {
                        res.nicknames.push({isimler: `${İsimYascik}`,rol: `Kadın`, execID: message.author.id, date: Date.now()})
                        res.save()}})
                        let Embed = new MessageEmbed().setAuthor(message.author.tag, message.author.avatarURL({dynamic: true}))
                        rowButton.components[0].setDisabled(true) 
                        rowButton.components[1].setDisabled(true) 
                        button.update({ embeds: [Embed.setColor(client.renk.renksiz).setDescription(`${target} kişisinin ismi ${name} | ${age} olarak değiştirildi\n\n**KADIN** olarak kayıt edildi!`)],components: [rowButton] })
                        const button12 = new MessageButton()
                        .setCustomId('hg')
                        .setLabel('Hadi Selam Ver!')
                        .setEmoji("🎉")
                        .setStyle('SECONDARY')
                        const r2owButton = new MessageActionRow().addComponents(button12)
                        client.channels.cache.get(chatKANAL).send({content: client.ayarlar.chatMesajı.replace("-member-", target)}).then(msg => msg.delete({
                        timeout: 1000 * 10
                    }))
                    await randMiss.findOneAndUpdate({ userID: message.member.id, "Mission.MISSION": "teyit" }, { $inc: { Check: 1 } }, { upsert: true });
                    client.easyMission(message.author.id, "teyit", 1)
                    return client.addAudit(message.author.id, 1, "Kadin");
                })
    
            } 
        })
        var filter = (button) => button.user.id;
        const collector2 = message.channel.createMessageComponentCollector({ filter, time: 30000 })
        collector2.on('collect', async (button) => {

            if (button.customId === "hg") {
                let user = button.member;
                let member = button.guild.members.cache.get(user.id);
                button.reply({content:`:tada: ${member} Sana Selam Yolladı!`})
    
            }
        })
       
        
    
    }}
    function dateToUnixEpoch(date) {
        return `<t:${Math.floor(Math.floor(date) / 1000)}:R>`
      }
        exports.conf = {
            aliases: ["erkek","Erkek","Kadın","kadın","e","k","E","K","woman","Man","man","Woman","kız","pipili"]
        }
        exports.help = {
            name: 'kayıt'
        }  