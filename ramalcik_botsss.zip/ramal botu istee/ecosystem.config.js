
const Sunucu_1 = "Knaves";
module.exports = {
    apps: [
        {
            name: `Operator`,
            namespace: "ramal_V13_Pub",
            script: "./Operator/main.js",
            watch: false
        },
        {
            name: `Statistics`,
            namespace: "ramal_V13_Pub",
            script: "./Statistics/main.js",
            watch: true
        },
        {
            name: `Fundamental`,
            namespace: "ramal_V13_Pub",
            script: "./Fundamental/main.js",
            watch: false
        },
    
    ]
};
