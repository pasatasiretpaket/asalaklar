exports.version = 1.0
exports.GiveawaysManager = require('./src/Manager');
exports.Giveaway = require('./src/Giveaway');
