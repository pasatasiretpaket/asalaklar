# pm2-bots
Proje Hakkında Bilgi
Selam,cartel(münür) ile tanıdığımız kardesimle acarın paylasmis olduğu botlari düzenleyip size sunmaya karar verdik.

Not: Cartelin yani münürün ebesine neyse şey şaka sız seviom seni münür her neyse paylaştık baka bilirsiniz 
şimdiden söylüyorum biz baktık düzenledik 0 hata sonradan gelip hatalı bot attınız falan demeyin zaten web yüzünden hatalar veriodu onuda düzeltti münür
